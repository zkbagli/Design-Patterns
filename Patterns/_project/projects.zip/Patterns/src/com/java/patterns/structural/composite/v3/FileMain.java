package com.java.patterns.structural.composite.v3;

public class FileMain {
	public static void main(final String[] args) {
		IFile dir1 = new Directory("osman");
		IFile file1 = new Directory("file1");
		IFile file2 = new Directory("file2");
		IFile file3 = new Directory("file3");
		dir1.addElement(file1);
		dir1.addElement(file2);
		dir1.addElement(file3);
		IFile dir2 = new Directory("Yay");
		dir1.addElement(dir2);
		IFile file4 = new Directory("file4");
		IFile file5 = new Directory("file5");
		IFile file6 = new Directory("file6");
		dir2.addElement(file4);
		dir2.addElement(file5);
		dir2.addElement(file6);

		System.out.println(dir1);
	}
}

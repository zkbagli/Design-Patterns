package com.java.patterns.structural.bridge.v2;

public abstract class AbstractArabaType implements IArabaType {

	protected int hiz;

	protected String name;

	AbstractArabaType(final int hiz, final String name) {
		this.hiz = hiz;
		this.name = name;

	}
}

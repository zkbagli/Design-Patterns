package com.java.patterns.structural.bridge.v2;

public class ElektrirkliAraba extends AbstractArabaType {

	public ElektrirkliAraba(final int hiz, final String name) {
		super(hiz,
		      name);
	}

	@Override
	public void git() {
		System.out.println("Elektirikli " + this.name + " hizi " + this.hiz + " gidiyor");
	}

}

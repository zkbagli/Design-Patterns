package com.java.patterns.structural.decorator;

public abstract class CondimentDecorator extends Beverage {

	protected final Beverage beverage;
	protected String name;
	protected double cost;

	public CondimentDecorator(final Beverage beverage, final String name, final double cost) {
		super();
		this.beverage = beverage;
		this.name = name;
		this.cost = cost;
	}

	@Override
	public String getDescription() {
		return this.beverage.getDescription() + ", " + this.name;
	}

	@Override
	public double cost() {
		return this.cost + this.beverage.cost();
	}

}

package com.java.patterns.creational.abstractfactory;

public class CPU_x86 implements CPU {

}

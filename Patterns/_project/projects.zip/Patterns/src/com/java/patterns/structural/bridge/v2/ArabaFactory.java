package com.java.patterns.structural.bridge.v2;

public class ArabaFactory {
	public static IAraba createAraba(final EAraba araba, final EArabaType arabaType) {
		switch (araba) {

		case BMW:
			return new BMW(arabaType);
		case MERCEDES:
			return new Mercedes(arabaType);
		default:
			return new BMW(arabaType);
		}
	}
}

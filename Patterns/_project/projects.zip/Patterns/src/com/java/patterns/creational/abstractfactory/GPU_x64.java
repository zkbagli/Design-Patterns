package com.java.patterns.creational.abstractfactory;

public class GPU_x64 implements GPU {

}

package com.java.patterns.structural.proxy.v2;

public interface Animal {

    public void getSound();

}
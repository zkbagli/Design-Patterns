package com.java.patterns.structural.adapter;

public abstract class AbstractShape implements IShape {

	@Override
	public void drawEx(final int x1, final int y1, final int x2, final int y2, final int rec) {
		throw new UnsupportedOperationException();
	}
}

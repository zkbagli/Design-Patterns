package com.java.patterns.structural.composite.v3;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractFile implements IFile {
	private String name;
	protected List<IFile> files = null;

	public AbstractFile(final String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public void addElement(final IFile file) {
		if (this.files == null) {
			this.files = new ArrayList<>();
		}
		this.addElementEx(file);
	}

	abstract void addElementEx(IFile file);

	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("name:");
		stringBuilder.append(this.name);
		stringBuilder.append(" ");

		if (this.files != null) {
			stringBuilder.append(this.files.toString());
		} else {
			stringBuilder.append("null");
		}
		return stringBuilder.toString();
	}

}

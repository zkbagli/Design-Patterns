package com.java.patterns.structural.decorator;

public class Milk extends CondimentDecorator {

	public Milk(final Beverage beverage) {
		super(beverage,
		      "Milk",
		      0.10D);
	}

}

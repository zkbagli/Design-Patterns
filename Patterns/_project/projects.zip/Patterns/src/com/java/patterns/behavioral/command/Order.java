package com.java.patterns.behavioral.command;

public interface Order {
    public abstract void execute();
}
package com.java.patterns.behavioral.strategy;

public interface IStrategy {

    public void operation();
}

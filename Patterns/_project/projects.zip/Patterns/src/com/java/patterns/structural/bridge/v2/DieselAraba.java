package com.java.patterns.structural.bridge.v2;

public class DieselAraba extends AbstractArabaType {

	public DieselAraba(final int hiz, final String name) {
		super(hiz,
		      name);
	}

	@Override
	public void git() {
		System.out.println("Diesel " + this.name + " hizi " + this.hiz + " gidiyor");
	}

}

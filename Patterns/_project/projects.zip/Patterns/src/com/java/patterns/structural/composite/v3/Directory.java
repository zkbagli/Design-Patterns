package com.java.patterns.structural.composite.v3;

public class Directory extends AbstractFile {

	public Directory(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	void addElementEx(final IFile file) {
		this.files.add(file);
	}

}

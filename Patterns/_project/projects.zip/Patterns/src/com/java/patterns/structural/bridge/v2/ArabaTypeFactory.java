package com.java.patterns.structural.bridge.v2;

public class ArabaTypeFactory {
	static public IArabaType createArabaType(final EArabaType arabaType, final int hiz, final String name) {
		switch (arabaType) {

		case BENZINLI:
			return new BenzinliAraba(hiz,
			                         name);
		case DIESEL:
			return new DieselAraba(hiz,
			                       name);
		case ELEKTIRIKLI:
			return new ElektrirkliAraba(hiz,
			                            name);
		case HYBRID:
			return new HybridAraba(hiz,
			                       name);
		default:
			return new BenzinliAraba(hiz,
			                         name);
		}
	}
}

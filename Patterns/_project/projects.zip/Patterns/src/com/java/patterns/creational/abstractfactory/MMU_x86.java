package com.java.patterns.creational.abstractfactory;

public class MMU_x86 implements MMU {

}

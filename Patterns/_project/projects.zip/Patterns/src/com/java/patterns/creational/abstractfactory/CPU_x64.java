package com.java.patterns.creational.abstractfactory;

public class CPU_x64 implements CPU {

}

package com.java.patterns.structural.composite.v3;

public class File extends AbstractFile {

	public File(final String name) {
		super(name);
	}

	@Override
	void addElementEx(final IFile file) {
		throw new UnsupportedOperationException();

	}

}

package com.java.patterns.behavioral.interpreter.v2;

public abstract class Expression {
    abstract public boolean interpret(String str);
}
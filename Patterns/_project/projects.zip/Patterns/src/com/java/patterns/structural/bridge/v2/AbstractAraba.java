package com.java.patterns.structural.bridge.v2;

public abstract class AbstractAraba implements IAraba {

	private IArabaType createArabaType;

	public AbstractAraba(final String name, final EArabaType arabaType) {
		this.createArabaType = ArabaTypeFactory.createArabaType(arabaType,
		                                                        arabaType.getHiz(),
		                                                        name);
	}

	@Override
	public void git() {
		this.createArabaType.git();
	}

}

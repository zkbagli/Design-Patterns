package com.java.patterns.structural.bridge.v2;

public class Mercedes extends AbstractAraba {

	public Mercedes(final EArabaType arabaType) {
		super("Mercedes",
		      arabaType);
	}

	@Override
	public void dur() {
		System.out.println("Mercedes 100 m durdu");
	}

}

package com.java.patterns.structural.composite;

public class Page extends CompositeDocumentElement {

}

package com.java.patterns.structural.proxy.v1;

public interface OfficeInternetAccess {

    public void grantInternetAccess();

}

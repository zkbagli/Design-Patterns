package com.java.patterns.creational.abstractfactory;

public class GPU_x86 implements GPU {

}

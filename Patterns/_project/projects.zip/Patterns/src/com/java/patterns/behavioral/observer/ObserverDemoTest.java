package com.java.patterns.behavioral.observer;

import java.util.Scanner;

public class ObserverDemoTest {
	public static void main(final String[] args) {
		Subject sub = new Subject();
		// Client configures the number and type of Observers
		new HexObserver(sub);
		new OctObserver(sub);
		new BinObserver(sub);
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.print("\nEnter a number: ");
			sub.setState(scan.nextInt());
		}
	}

}

package com.java.patterns.structural.decorator;

public class Mocha extends CondimentDecorator {

	public Mocha(final Beverage beverage) {
		super(beverage,
		      "Mocha",
		      0.15D);
	}

}

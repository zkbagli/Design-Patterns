package com.java.patterns.creational.abstractfactory;

public interface MMU {

}

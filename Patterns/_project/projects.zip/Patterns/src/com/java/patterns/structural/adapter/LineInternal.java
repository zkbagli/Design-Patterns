package com.java.patterns.structural.adapter;

public class LineInternal extends AbstractShape {

	@Override
	public void draw(final int x1, final int y1, final int x2, final int y2) {
		System.out.println("Draw internal Line");
	}

}

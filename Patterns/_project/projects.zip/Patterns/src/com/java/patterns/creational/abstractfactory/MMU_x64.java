package com.java.patterns.creational.abstractfactory;

public class MMU_x64 implements MMU {

}

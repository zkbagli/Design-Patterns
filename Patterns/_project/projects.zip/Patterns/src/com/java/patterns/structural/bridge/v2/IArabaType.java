package com.java.patterns.structural.bridge.v2;

public interface IArabaType {
	void git();
}

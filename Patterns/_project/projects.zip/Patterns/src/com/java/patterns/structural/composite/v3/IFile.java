package com.java.patterns.structural.composite.v3;

public interface IFile {
	public void addElement(final IFile file);
}

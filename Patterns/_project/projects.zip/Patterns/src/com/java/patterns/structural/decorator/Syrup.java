package com.java.patterns.structural.decorator;

public class Syrup extends CondimentDecorator {

	public Syrup(final Beverage beverage) {
		super(beverage,
		      "Syrup",
		      0.12D);
	}

}

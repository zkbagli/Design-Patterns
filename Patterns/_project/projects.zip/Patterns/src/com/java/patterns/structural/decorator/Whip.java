package com.java.patterns.structural.decorator;

public class Whip extends CondimentDecorator {

	public Whip(final Beverage beverage) {
		super(beverage,
		      "Whip",
		      0.10D);
	}
}

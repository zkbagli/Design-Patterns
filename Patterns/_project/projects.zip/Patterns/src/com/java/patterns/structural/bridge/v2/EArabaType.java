package com.java.patterns.structural.bridge.v2;

public enum EArabaType {
	DIESEL(90), BENZINLI(110), ELEKTIRIKLI(70), HYBRID(95);

	private int hiz;

	private EArabaType(final int hiz) {
		this.hiz = hiz;

	}

	public int getHiz() {
		return this.hiz;
	}

}

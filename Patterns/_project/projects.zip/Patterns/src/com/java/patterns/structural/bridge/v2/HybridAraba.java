package com.java.patterns.structural.bridge.v2;

public class HybridAraba extends AbstractArabaType {

	public HybridAraba(final int hiz, final String name) {
		super(hiz,
		      name);
	}

	@Override
	public void git() {
		System.out.println("Hybrid " + this.name + " hizi " + this.hiz + " gidiyor");
	}

}

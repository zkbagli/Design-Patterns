package com.java.patterns.structural.bridge.v2;

public class BenzinliAraba extends AbstractArabaType {

	public BenzinliAraba(final int hiz, final String name) {
		super(hiz,
		      name);
	}

	@Override
	public void git() {
		System.out.println("Benzinli " + this.name + " hizi " + this.hiz + " gidiyor");
	}

}

package com.java.patterns.structural.bridge.v2;

public class ArabaMain {
	public static void main(final String[] args) {
		IAraba araba = ArabaFactory.createAraba(EAraba.MERCEDES,
		                                        EArabaType.BENZINLI);
		araba.git();
	}
}

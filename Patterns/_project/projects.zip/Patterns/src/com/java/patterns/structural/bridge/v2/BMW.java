package com.java.patterns.structural.bridge.v2;

public class BMW extends AbstractAraba {

	public BMW(final EArabaType arabaType) {
		super("BMW",
		      arabaType);
	}

	@Override
	public void dur() {
		System.out.println("Generic BMW 100 m durdu");
	}

}

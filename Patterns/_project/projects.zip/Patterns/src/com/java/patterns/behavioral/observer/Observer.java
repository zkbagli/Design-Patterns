package com.java.patterns.behavioral.observer;

abstract class Observer {
	protected Subject subj;

	public abstract void update();
}

class HexObserver extends Observer {
	public HexObserver(final Subject s) {
		this.subj = s;
		this.subj.attach(this);
	}

	@Override
	public void update() {
		System.out.print(" " + Integer.toHexString(this.subj.getState()));
	}
} // Observers "pull" information

class OctObserver extends Observer {
	public OctObserver(final Subject s) {
		this.subj = s;
		this.subj.attach(this);
	}

	@Override
	public void update() {
		System.out.print(" " + Integer.toOctalString(this.subj.getState()));
	}
} // Observers "pull" information

class BinObserver extends Observer {
	public BinObserver(final Subject s) {
		this.subj = s;
		this.subj.attach(this);
	} // Observers register themselves

	@Override
	public void update() {
		System.out.print(" " + Integer.toBinaryString(this.subj.getState()));
	}
}

class Subject {
	private Observer[] observers = new Observer[9];
	private int totalObs = 0;
	private int state;

	public void attach(final Observer o) {
		this.observers[this.totalObs++] = o;
	}

	public int getState() {
		return this.state;
	}

	public void setState(final int in) {
		this.state = in;
		this.notify();
	}

	public void call() {
		for (int i = 0; i < this.totalObs; i++) {
			this.observers[i].update();
		}
	}
}

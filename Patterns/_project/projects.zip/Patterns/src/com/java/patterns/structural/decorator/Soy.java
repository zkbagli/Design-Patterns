package com.java.patterns.structural.decorator;

public class Soy extends CondimentDecorator {

	public Soy(final Beverage beverage) {
		super(beverage,
		      "Soy",
		      0.12D);
	}

}

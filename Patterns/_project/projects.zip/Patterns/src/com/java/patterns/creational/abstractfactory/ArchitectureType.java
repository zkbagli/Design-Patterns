package com.java.patterns.creational.abstractfactory;

public enum ArchitectureType {
    x86,
    x64
}

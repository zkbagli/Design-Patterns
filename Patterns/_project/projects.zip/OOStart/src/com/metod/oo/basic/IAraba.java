package com.metod.oo.basic;

public interface IAraba {
	void git();

	void dur();
}

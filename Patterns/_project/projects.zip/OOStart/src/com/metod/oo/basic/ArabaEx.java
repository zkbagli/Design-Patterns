package com.metod.oo.basic;

public class ArabaEx extends Araba {
	public ArabaEx() {
		super("BMW");
		int a = 10;
	}
}

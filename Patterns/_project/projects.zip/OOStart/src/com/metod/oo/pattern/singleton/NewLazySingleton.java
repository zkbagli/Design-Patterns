package com.metod.oo.pattern.singleton;

public class NewLazySingleton {
	private static volatile NewLazySingleton instance = null;

	private NewLazySingleton() {
	}

	public static NewLazySingleton getInstance() {
		if (NewLazySingleton.instance == null) {
			synchronized (NewLazySingleton.class) {
				if (NewLazySingleton.instance == null) {
					NewLazySingleton.instance = new NewLazySingleton();
				}
			}
		}
		return NewLazySingleton.instance;
	}

	public String hello() {
		return "Hello from NewLazySingleton";
	}

}

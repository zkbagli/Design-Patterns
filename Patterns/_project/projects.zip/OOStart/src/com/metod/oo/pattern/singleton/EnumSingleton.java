package com.metod.oo.pattern.singleton;

public enum EnumSingleton implements IETest {
	INSTANCE {
		@Override
		public void test() {

		}

	},
	INSTANCE2 {
		@Override
		public void test() {

		}

		@Override
		public String hello() {
			return "Hello from INTANCE2";
		}

	};

	public String hello() {
		return "Hello from EnumSingleton";
	}
}

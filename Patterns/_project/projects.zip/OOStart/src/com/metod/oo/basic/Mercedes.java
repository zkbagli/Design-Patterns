package com.metod.oo.basic;

public class Mercedes extends ArabaImpl {

	@Override
	public void git() {
		System.out.println("Mercedes gidiyor");
	}
}

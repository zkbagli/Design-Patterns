package com.metod.oo.pattern.builder;

public class Immutable {
	private String name;
	private String surname;
	private int age1;
	private int age2;
	private int age3;
	private int age4;
	private int age5;
	private int age6;
	private int age7;
	private int age8;
	private int age9;
	private int age10;
	private int age11;
	private int age12;
	private int age13;
	private int age14;
	private int age15;
	private int age16;

	public Immutable(final String name, final String surname, final int age1, final int age2, final int age3,
			final int age4, final int age5, final int age6, final int age7, final int age8, final int age9,
			final int age10, final int age11, final int age12, final int age13, final int age14, final int age15,
			final int age16) {
		super();
		this.name = name;
		this.surname = surname;
		this.age1 = age1;
		this.age2 = age2;
		this.age3 = age3;
		this.age4 = age4;
		this.age5 = age5;
		this.age6 = age6;
		this.age7 = age7;
		this.age8 = age8;
		this.age9 = age9;
		this.age10 = age10;
		this.age11 = age11;
		this.age12 = age12;
		this.age13 = age13;
		this.age14 = age14;
		this.age15 = age15;
		this.age16 = age16;
	}

	public String getName() {
		return this.name;
	}

	public String getSurname() {
		return this.surname;
	}

	public int getAge1() {
		return this.age1;
	}

	public int getAge2() {
		return this.age2;
	}

	public int getAge3() {
		return this.age3;
	}

	public int getAge4() {
		return this.age4;
	}

	public int getAge5() {
		return this.age5;
	}

	public int getAge6() {
		return this.age6;
	}

	public int getAge7() {
		return this.age7;
	}

	public int getAge8() {
		return this.age8;
	}

	public int getAge9() {
		return this.age9;
	}

	public int getAge10() {
		return this.age10;
	}

	public int getAge11() {
		return this.age11;
	}

	public int getAge12() {
		return this.age12;
	}

	public int getAge13() {
		return this.age13;
	}

	public int getAge14() {
		return this.age14;
	}

	public int getAge15() {
		return this.age15;
	}

	public int getAge16() {
		return this.age16;
	}

}

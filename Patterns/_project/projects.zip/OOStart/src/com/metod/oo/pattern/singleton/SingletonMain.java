package com.metod.oo.pattern.singleton;

public class SingletonMain {

	public static void main(final String[] args) {
		String hello = Singleton.getInstance().hello();
		System.out.println(hello);

		hello = LazySingleton.getInstance().hello();
		System.out.println(hello);

		hello = EnumSingleton.INSTANCE.hello();
		System.out.println(hello);
	}

}

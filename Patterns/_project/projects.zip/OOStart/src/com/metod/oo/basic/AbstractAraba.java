package com.metod.oo.basic;

public abstract class AbstractAraba implements IAraba {
	@Override
	public void dur() {
		System.out.println("Duruyorum");
	}
}

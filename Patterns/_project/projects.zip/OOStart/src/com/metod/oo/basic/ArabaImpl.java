package com.metod.oo.basic;

public class ArabaImpl extends AbstractAraba {

	@Override
	public void git() {
		System.out.println("gidiyorum");
	}

}

package com.metod.oo.basic;

public class ArabaMain {

	public static void main(final String[] args) {
		IAraba arabaIntf = null;
		switch (Integer.parseInt(args[0])) {
		case 0:
			arabaIntf = new BMW();
		case 1:
			arabaIntf = new Mercedes();

		default:
			arabaIntf = new BMW();
		}

		arabaIntf.git();

		IAraba araba = ArabaFactory.generateAraba(1);
		araba.git();

		IAraba araba2 = ArabaFactory.generateAraba(2);
		araba2.git();

		// Araba araba = new Araba("320", "BMW", 2007);
		//
		// Araba2 araba2 = Araba2.generateArabaFull("320", "BMW", 2007);

	}

}

package com.metod.oo.basic;

public class Araba2 {
	private String name;
	private String brand;
	int year;

	protected Araba2() {
	}

	public static Araba2 generateArabaFull(final String name, final String brand, final int year) {
		if (name == null) {
			throw new IllegalArgumentException();
		}
		Araba2 araba2 = new Araba2();

		araba2.name = name;
		araba2.brand = brand;
		araba2.year = year;
		return araba2;

	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		if ((name == null) || name.isEmpty()) {
			throw new IllegalArgumentException("name can not be null");
		}
		this.name = name;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(final String brand) {
		this.brand = brand;
	}

	public int getYear() {
		return this.year;
	}

	public void setYear(final int year) {
		this.year = year;
	}

}

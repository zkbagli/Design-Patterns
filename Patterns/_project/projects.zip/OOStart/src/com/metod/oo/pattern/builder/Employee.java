package com.metod.oo.pattern.builder;

import java.util.Date;

public class Employee {
	private String name;
	private String surname;
	private Date birthdate;

	private Employee() {

	}

	public String getName() {
		return this.name;
	}

	public String getSurname() {
		return this.surname;
	}

	public Date getBirthdate() {
		return this.birthdate;
	}

	public static EmployeeBuilder builder() {
		return new EmployeeBuilder();
	}

	public static class EmployeeBuilder {
		private String name;
		private String surname;
		private Date birthdate;

		private EmployeeBuilder() {
		}

		public String getName() {
			return this.name;
		}

		public EmployeeBuilder setName(final String name) {
			this.name = name;
			return this;
		}

		public String getSurname() {
			return this.surname;
		}

		public EmployeeBuilder setSurname(final String surname) {
			this.surname = surname;
			return this;
		}

		public Date getBirthdate() {
			return this.birthdate;
		}

		public EmployeeBuilder setBirthdate(final Date birthdate) {
			this.birthdate = birthdate;
			return this;
		}

		public Employee build() {
			if (this.name == null) {
				throw new IllegalArgumentException("Name can not be null");
			}
			Employee employee = new Employee();
			employee.name = this.name;
			employee.surname = this.surname;
			employee.birthdate = this.birthdate;
			return employee;
		}

	}
}

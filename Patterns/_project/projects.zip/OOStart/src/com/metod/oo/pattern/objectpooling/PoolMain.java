package com.metod.oo.pattern.objectpooling;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PoolMain {

	public static void main(final String[] args) {
		Connection connection = null;
		try {
			connection = Manager.getInstance()
			                    .getConnection();
			PreparedStatement prepareStatement = connection.prepareStatement("");
			ResultSet executeQuery = prepareStatement.executeQuery();
			// loop resultset
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e2) {
				}
			}
		}
	}

}

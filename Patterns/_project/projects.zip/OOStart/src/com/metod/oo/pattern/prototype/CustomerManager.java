package com.metod.oo.pattern.prototype;

import java.util.HashMap;
import java.util.Map;

public class CustomerManager {
	private Map<String, Customer> customerMap = new HashMap<>();

	public Customer getCustomer(final String name) {
		Customer customer = this.customerMap.get(name);
		if (customer != null) {
			try {
				return (Customer) customer.clone();
			} catch (CloneNotSupportedException e) {
			}
		}
		// DB ye git al ve
		Customer customer2 = new Customer();
		this.customerMap.put(customer2.getName(),
		                     customer2);
		try {
			return (Customer) customer2.clone();
		} catch (CloneNotSupportedException e) {
		}
		return null;
	}
}

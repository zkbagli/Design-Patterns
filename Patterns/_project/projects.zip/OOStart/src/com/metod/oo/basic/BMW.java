package com.metod.oo.basic;

public class BMW extends ArabaImpl {

	@Override
	public void git() {
		System.out.println("BMW gidiyor");
	}
}

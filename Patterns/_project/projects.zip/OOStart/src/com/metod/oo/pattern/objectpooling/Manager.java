package com.metod.oo.pattern.objectpooling;

import java.sql.Connection;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Manager {
	private static volatile Manager instance = null;

	private Manager() {
	}

	public static Manager getInstance() {
		if (Manager.instance == null) {
			synchronized (Manager.class) {
				if (Manager.instance == null) {
					Manager.instance = new Manager();
					// Init
				}
			}
		}
		return Manager.instance;
	}

	private BlockingQueue<Connection> pool = new ArrayBlockingQueue<>(1000);

	public Connection getConnection() throws InterruptedException {
		return this.pool.take();
	}

	public void returnConnection(final Connection connection) {
		this.pool.add(connection);
	}

}

package com.metod.oo;

public class Main {
	public static void main(final String[] args) {

	}
}

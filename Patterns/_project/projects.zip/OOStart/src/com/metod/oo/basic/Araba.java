package com.metod.oo.basic;

public class Araba {
	private String name;
	private String brand;
	private int year;

	public Araba(final String name, final String brand, final int year) {
		super();
		this.name = name;
		this.brand = brand;
		this.year = year;
	}

	public Araba(final String name) {
		super();
		this.name = name;
	}

	public Araba(final String name, final String brand) {
		super();
		this.name = name;
		this.brand = brand;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		if ((name == null) || name.isEmpty()) {
			throw new IllegalArgumentException("name can not be null");
		}
		this.name = name;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(final String brand) {
		this.brand = brand;
	}

	public int getYear() {
		return this.year;
	}

	public void setYear(final int year) {
		this.year = year;
	}

}

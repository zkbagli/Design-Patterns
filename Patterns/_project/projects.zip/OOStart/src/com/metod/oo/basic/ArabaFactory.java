package com.metod.oo.basic;

public class ArabaFactory {

	public static IAraba generateAraba(final int index) {
		switch (index) {
		case 0:
			return new BMW();
		case 1:
			return new Mercedes();

		default:
			return new BMW();
		}
	}

}

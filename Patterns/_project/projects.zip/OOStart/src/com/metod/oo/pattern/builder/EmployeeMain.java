package com.metod.oo.pattern.builder;

import java.util.Date;

public class EmployeeMain {
	public static void main(final String[] args) {
		Employee employee = Employee.builder()
		                            .setName("osman")
		                            .setBirthdate(new Date())
		                            .setSurname("yaycioglu")
		                            .build();
	}
}

package com.metod.oo.pattern.singleton;

public interface IETest {
	void test();
}
